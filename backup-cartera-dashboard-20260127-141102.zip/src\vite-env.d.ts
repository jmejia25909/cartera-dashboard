/// <reference types="vite/client" />

declare global {

}

export {};